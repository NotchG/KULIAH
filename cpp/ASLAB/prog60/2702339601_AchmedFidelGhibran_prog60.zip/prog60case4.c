#include <stdio.h>

int main() {
    int n, s;
    scanf("%d", &n);
    int array[n];
    for(int i = 0;i < n;scanf("%d", array[i++]));
    printf("%d", array[2]);
    return 0;
}