#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    int A[n];
    int B[n];
    int C[n];
    int F[n];
    
    for (int i = 0;i < n;i++) {
        
    }
    
    return 0;
}