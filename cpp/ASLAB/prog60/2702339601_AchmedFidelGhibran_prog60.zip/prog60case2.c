#include <stdio.h>

int main() {
    unsigned long long int a;
    unsigned long long int b;

    scanf("%llu %llu", &a, &b);

    printf("%llu", b);
    return 0;
}